/* ============================================================================
 * Game — state machine, run lifecycle, spawning, economy, and the fixed-step
 * update loop. This is the only module that knows about all the others.
 * ========================================================================== */

class Game {
  constructor(canvas) {
    this.renderer = new Renderer(canvas);
    this.ui = new UI(this);
    this.input = new Input(this);
    this.fx = new FX(this);

    this.state = 'title';          // title | play | paused | over
    this.time = 0;
    this.acc = 0;
    this.shakeAmt = 0;
    this.shakeX = 0; this.shakeY = 0;
    this.cam = { x: 0, y: 0 };
    this.lights = [];
    this.tempLights = [];

    this.world = null;
    this.player = null;
    this.enemies = [];
    this.gems = [];
    this.dynamites = [];
    this.blocks = [];
    this.worms = [];
    this.carry = [];
    this.checkpointLock = null;
    this.demo = null;              // the autopilot playing behind the title (src/demo.js)
    this.tutorial = null;          // the practice mine's script (src/tutorial.js)

    this.save = this.load();
    // A live mine sits behind the title panel instead of a black rectangle,
    // with a miner at work in it.
    this.newCampaign(true);

    window.addEventListener('resize', () => this.renderer.resize());
    window.addEventListener('orientationchange', () => setTimeout(() => this.renderer.resize(), 260));
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'play') this.togglePause();
    });

    this.ui.title();
    Music.play('menu');
  }

  /* ------------------------------------------------------------ persistence */

  /**
   * The save holds records and settings only. There is no vault and no
   * permanent upgrade: every campaign starts from nothing, so a strong past
   * run can never buy the next one an easy start.
   */
  load() {
    // Screen shake starts off for players whose device asks for less motion.
    const calm = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    const blank = { best: 0, bestMine: 0, audio: true, music: true, shake: !calm, daily: null, stats: Stats.blank(), seen: {}, tutorial: null };
    try {
      // An older save still knows the player's deepest dive and sound setting;
      // any gold and upgrades belong to an old economy and are dropped.
      let raw = localStorage.getItem(CFG.saveKey);
      for (const k of CFG.legacySaveKeys) raw = raw || localStorage.getItem(k);
      if (!raw) return blank;
      const s = JSON.parse(raw);
      return {
        best: s.best || 0,
        bestMine: s.bestMine || 0,
        audio: s.audio !== false,
        music: s.music !== false,
        shake: s.shake !== undefined ? s.shake !== false : !calm,
        // Today's best daily haul on this device: { date, best }.
        daily: s.daily && typeof s.daily.date === 'string' ? { date: s.daily.date, best: s.daily.best || 0 } : null,
        // Lifetime counters behind the achievements — see src/stats.js.
        stats: Stats.from(s.stats),
        // Hazards the player has already been warned about: { gas, worm }.
        seen: s.seen && typeof s.seen === 'object' ? { gas: !!s.seen.gas, worm: !!s.seen.worm } : {},
        // Has the tutorial been offered ('offered') or played through ('done')?
        tutorial: s.tutorial === 'offered' || s.tutorial === 'done' ? s.tutorial : null,
      };
    } catch (e) { return blank; }
  }

  persist() {
    try { localStorage.setItem(CFG.saveKey, JSON.stringify(this.save)); } catch (e) { /* private mode */ }
  }

  /** Records go; settings stay. The caller decides which panel to show next. */
  wipeSave() {
    this.save = { best: 0, bestMine: 0, audio: Sfx.enabled, music: Music.enabled, shake: this.save.shake, daily: null, stats: Stats.blank(), seen: {}, tutorial: this.save.tutorial };
    this.persist();
    Highscore.reset();
  }

  /**
   * Change the lifetime counters. Any achievement level this crosses is
   * announced and saved straight away; plain counting waits for the next
   * save, which every mine's end makes anyway.
   */
  track(change) {
    if (this.demo || this.tutorial) return;   // the title-screen miner's and the practice mine's work don't count
    const s = this.save.stats;
    const before = Stats.levels(s);
    change(s);
    const after = Stats.levels(s);
    let earned = false;
    CFG.achievements.forEach((a, i) => {
      // A leap past several bars at once announces only the best of them.
      if (after[i] > before[i]) { this.ui.achievement(a, after[i]); earned = true; }
    });
    if (earned) this.persist();
  }

  /** Every enemy death lands here, with how it happened. */
  recordKill(e, cause) {
    if (cause === 'worm') return;   // the Tunneler's doing, not the player's
    const who = e instanceof Bat ? 'bat' : 'caveBug';
    const how = KILL_CAUSES.indexOf(cause) >= 0 ? cause : 'pick';
    this.track(s => { s.kills[who][how]++; });
  }

  /* ---------------------------------------------------------- run lifecycle */

  /**
   * A campaign is a chain of mines. Upgrades live here, not in the save: they
   * carry from one mine to the next and die with the campaign.
   *
   * `score` is what is already safe — the hauls of mines escaped with the
   * Heartstone. The rest are the ledger the summary adds up for the player.
   * `scoreId` is the board row this campaign has written, so each later escape
   * (and the final result) updates one row instead of adding another. `runId`
   * does the same for the online boards; `playMs` is mine time across the
   * whole campaign.
   *
   * `mode` 'daily' makes this a DAILY attempt: a single mine whose terrain is
   * built from today's UTC date, so every player digs the same one. It is
   * still mine 1 on base stats; escaping it ends the attempt. `daily` holds
   * the date it started on — a run that crosses midnight counts for that day.
   *
   * `mode` 'hardcore' is an endless campaign on CFG.hardcore's terms: half the
   * lanterns, no refill between mines, a weaker revive, a bigger haul and a
   * board of its own. `bonus` is what that extra share has added to `score`;
   * `kit` is the health and dynamite carried from one mine into the next.
   */
  newCampaign(quiet, mode) {
    const daily = mode === 'daily' ? utcDate(0) : null;
    if (!quiet) this.track(s => { s.runs++; });
    this.campaign = {
      mine: 1, upgrades: {}, score: 0,
      found: 0, spent: 0, hearts: 0, depth: 0, gems: 0, bonus: 0,
      scoreId: 0, result: null,
      runId: newRunId(), playMs: 0, online: null,
      daily, dailyRecord: false,
      hardcore: mode === 'hardcore', kit: null,
      revived: false,          // the one ad revive this run gets
    };
    this.startMine(quiet);
  }

  /**
   * The practice mine: a fixed map, base stats, no clock, no random enemies,
   * nothing scored, saved or uploaded. See src/tutorial.js.
   */
  startTutorial() {
    this.campaign = {
      mine: 1, upgrades: {}, score: 0,
      found: 0, spent: 0, hearts: 0, depth: 0, gems: 0,
      scoreId: 0, result: null,
      runId: null, playMs: 0, online: null,
      daily: null, dailyRecord: false,
      revived: false, tutorial: true,
    };
    this.startMine();
  }

  /** Per-mine numbers. `lost` is what was still being carried at the end. */
  resetRunStats() { this.runStats = { depth: 0, lost: 0, hauled: 0 }; }

  /** How hard a mine leans on the player; the last entry covers every deeper one. */
  threat() {
    const t = CFG.campaign.threat;
    return t[Math.min(this.campaign.mine, t.length) - 1];
  }

  /**
   * Which hazards this mine has. A campaign brings them in a mine at a time
   * (gas from `CFG.gas.fromMine`, the worm from `CFG.worm.fromMine`). The
   * daily rolls for each from its seed, so a given day has them for everyone
   * or for no one; it then gets the gentlest level of each.
   * Returns { gas: pockets per 100 rows, worm: seconds between passes (0 = none) }.
   */
  hazards(seed) {
    const c = this.campaign;
    const level = (list, from) => list[Math.min(c.mine - from, list.length - 1)];
    if (c.daily) {
      const r = new RNG(seed ^ 0x2c1b3c6d);
      return {
        gas: r.chance(CFG.gas.dailyChance) ? CFG.gas.pockets[0] : 0,
        worm: r.chance(CFG.worm.dailyChance) ? CFG.worm.every[0] : 0,
      };
    }
    return {
      gas: c.mine >= CFG.gas.fromMine ? level(CFG.gas.pockets, CFG.gas.fromMine) : 0,
      worm: c.mine >= CFG.worm.fromMine ? Math.max(CFG.worm.minEvery, level(CFG.worm.every, CFG.worm.fromMine)) : 0,
    };
  }

  /**
   * `quiet` builds the title screen's mine: no toast, nothing saved, and the
   * demo miner at the controls (unless the device asks for reduced motion).
   */
  startMine(quiet) {
    if (!quiet) { Sfx.init(); Music.play('game', true); }
    const calm = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    this.demo = quiet && !calm ? new Demo() : null;
    Sfx.setDim(quiet ? CFG.demo.volume : 1);
    document.body.classList.toggle('attract', !!quiet);
    Music.duck(false);
    Sfx.setEnabled(this.save.audio !== false);
    Sfx.stopRumble();

    const mine = this.campaign.mine;
    const heartRow = CFG.world.heartstoneRow + (mine - 1) * CFG.campaign.heartstoneStep;
    const tut = !!this.campaign.tutorial;
    this.tutorial = tut ? new Tutorial() : null;
    // The practice mine has no eruption clock: the Heartstone is the only thing that wakes it.
    this.fuse = tut ? Infinity : CFG.lava.fuse + (mine - 1) * CFG.campaign.fusePerMine;

    const seed = this.campaign.daily ? dailySeed(this.campaign.daily) : (Math.random() * 0xffffffff) >>> 0;
    const hz = tut ? { gas: 0, worm: 0 } : this.hazards(seed);
    const hard = this.campaign.hardcore;
    this.world = new World(seed, this, heartRow, hz.gas, tut ? CFG.tutorial.map : null,
      hard ? CFG.hardcore.lanternSpacing : 1);
    this.player = new Player(this.world.spawnPoint.x, this.world.spawnPoint.y, this.campaign.upgrades);
    // Hardcore: the wounds and the empty satchel come down with you.
    const kit = this.campaign.kit;
    if (kit) {
      this.player.health = clamp(kit.health, 1, this.player.maxHealth);
      this.player.dynamite = clamp(kit.dynamite, 0, this.player.dynMax);
      this.campaign.kit = null;
    }
    this.enemies.length = 0;
    this.gems.length = 0;
    this.dynamites.length = 0;
    this.blocks.length = 0;
    this.worms.length = 0;
    this.carry.length = 0;
    this.fx.clear();
    this.wormEvery = hz.worm;
    this.wormTimer = hz.worm * randRange(CFG.worm.firstDelay);
    this._hissAt = -1; this._whooshAt = -1;
    this.tempLights.length = 0;

    this.volcano = false;
    this.lavaSpeed = CFG.lava.riseSpeed;
    this.lavaShakeTimer = 0;
    this.deathAnim = 0;
    this.spawnTimer = CFG.spawn.interval;
    // The eruption clock. It only advances while the mine is actually being
    // played, so a paused game or the title-screen mine never burns it down.
    this.runTime = 0;
    // Wall time in this mine, eruption or not — what the fastest escape is timed on.
    this.mineTime = 0;
    this.nextWarn = 0;
    this.resetRunStats();
    if (!this.campaign.revived && !tut) Ads.preload();

    // Standing on the home lantern at spawn shouldn't instantly open the shop.
    this.lockCheckpoint(Math.floor(this.player.x), Math.floor(this.player.y));

    this.cam.x = this.player.x;
    this.cam.y = this.player.y;

    if (!quiet) this.ui.hide();
    this.ui.syncHealth(this.player);
    this.ui.syncHat(this.player);
    this.ui.syncDynamite(this.player);
    this.ui.syncWallet(this);
    this.ui.syncTimer(this);
    this.input.reset();
    this.state = quiet ? 'title' : 'play';
    // From here on a reload or a Back press would cost the player a run.
    ExitGuard.sync();
    this.ui.syncCoach(this);
    if (!quiet && !tut) {
      this.save.bestMine = Math.max(this.save.bestMine || 0, mine);
      this.persist();
      this.ui.toast(this.campaign.daily ? loc('toast.daily', { d: this.campaign.daily })
        : mine > 1 ? loc('toast.mineN', { n: mine })
        : hard ? loc('toast.hardcore') : loc('toast.digDown'), 1800);
    }
  }

  /** Back to the title, with a fresh idle mine behind it. */
  toTitle() {
    this.newCampaign(true);
    ExitGuard.sync();
    Music.play('menu');
    this.ui.title();
  }

  /** Straight into the next mine: same gear, empty pockets. */
  nextMine() {
    const c = this.campaign, p = this.player;
    if (c.hardcore) c.kit = { health: p.health, dynamite: p.dynamite };
    c.mine++;
    this.startMine();
  }

  /**
   * True while leaving the page would throw work away. A mine in progress
   * lives only in memory — the save holds records, settings and the scores of
   * mines already escaped, nothing else — so every live mine counts, carrying
   * loot or not.
   */
  runAtRisk() {
    if (this.state !== 'play' && this.state !== 'paused') return false;
    if (this.tutorial) return false;   // the practice mine has nothing to lose
    return !!this.player && !this.player.dead;
  }

  /**
   * End the current mine. `kind` is:
   *   'win'     — surfaced with the Heartstone; the campaign goes on
   *   'cashout' — walked out without it; the campaign ends, haul kept
   *   'death' / 'abandon' — the campaign ends, this mine's pockets are lost
   */
  endRun(kind) {
    if (this.state === 'over') return;
    if (this.tutorial) { this.toTitle(); return; }   // nothing of the practice mine is ever recorded
    const c = this.campaign;
    if (kind === 'death') this.track(s => { s.deaths++; });
    if (kind === 'death' || kind === 'abandon') {
      this.runStats.lost = this.carryValue();
      const lost = this.runStats.lost;
      this.track(s => { s.biggestLoss = Math.max(s.biggestLoss, lost); });
      this.carry.length = 0;
      this.player.hasHeartstone = false;
    }
    this.save.best = Math.max(this.save.best || 0, this.runStats.depth);
    c.depth = Math.max(c.depth, this.runStats.depth);

    if (c.daily) {
      // A daily attempt never touches the endless haul board; it keeps its own
      // best-of-the-day instead.
      const d = this.save.daily && this.save.daily.date === c.daily ? this.save.daily : { date: c.daily, best: 0 };
      c.dailyRecord = c.score > d.best;
      this.save.daily = { date: c.daily, best: Math.max(d.best, c.score) };
    } else {
      // The board is written on every escape as well as at the end, so a player
      // who closes the tab between mines still has the mines they escaped.
      c.result = Highscore.submit({
        value: c.score,
        depth: c.depth,
        gems: c.gems,
        mine: c.mine,
        kind,
      }, c.scoreId, c.hardcore ? 'hardcore' : 'endless');
      if (c.result) c.scoreId = c.result.id;
    }

    c.playMs += Math.round(this.runTime * 1000);
    this.submitOnline(kind);

    this.persist();
    Sfx.stopRumble();
    this.state = 'over';
    Music.duck(false);
    Music.play('menu');
    this.input.reset();
    this.ui.syncWallet(this);
    this.ui.syncTimer(this);
    this.ui.summary(this, kind);
  }

  /**
   * Queue this campaign's latest state for the online boards. The same run id
   * is re-sent after every mine, and the server only ever moves it forward.
   * `campaign.online` tracks how the upload went so the summary can say so.
   */
  submitOnline(kind) {
    const c = this.campaign;
    if (!Online.enabled) return;
    c.online = { state: 'sending' };
    Online.submitRun({
      client_run_id: c.runId,
      mode: c.daily ? 'daily' : c.hardcore ? 'hardcore' : 'endless',
      daily_date: c.daily,
      score: c.score,
      mines_escaped: c.hearts,
      max_depth: c.depth,
      gems: c.gems,
      heartstone: kind === 'win',
      result: kind,
      revived: c.revived,
      duration_ms: c.playMs,
      game_version: CFG.online.gameVersion,
      gen_version: CFG.online.genVersion,
      played_at: new Date().toISOString(),
    }).then(res => {
      if (this.campaign !== c) return;            // a new campaign started meanwhile
      if (!res.ok) { c.online = { state: res.queued ? 'queued' : 'refused' }; this.ui.syncOnline(this); return; }
      return Online.myRanks().then(r => {
        if (this.campaign !== c) return;
        const row = r.ok && Array.isArray(r.data) ? r.data[0] : null;
        // The daily rank only means something while it is still that day.
        const rank = !row || r.cached ? null : c.daily ? (c.daily === utcDate(0) ? row.daily_rank : null)
          : c.hardcore ? row.hardcore_rank : row.endless_rank;
        c.online = { state: 'sent', rank };
        this.ui.syncOnline(this);
      });
    });
  }

  killPlayer() {
    if (this.player.dead) return;
    this.player.dead = true;
    this.deathAnim = 0;
    Sfx.play('death');
    this.shake(18);
    this.fx.burst(this.player.x, this.player.y, 26, ['#ff5d5d', '#ffd08a', '#3d6fb4'], { speed: 8, life: 0.9, size: 0.2 });
    // Dying in the practice mine costs nothing: Tutorial.update gets the miner back up.
    if (this.tutorial) { this.ui.banner(loc('sum.died'), ''); return; }
    // One ad revive per run, and only if an ad is actually on hand: the
    // offer must never be a button that leads nowhere.
    const c = this.campaign;
    const canRevive = !c.revived && Ads.available();
    if (!canRevive) {
      this.ui.banner(loc('sum.died'),
        this.carryValue() > 0 ? loc('banner.lostInDark', { v: fmt(this.carryValue()) }) : '');
    }
    setTimeout(() => {
      if (this.state !== 'play' || this.campaign !== c || !this.player.dead) return;
      if (canRevive && Ads.available()) this.offerRevive();
      else this.endRun('death');
    }, canRevive ? CFG.revive.delay * 1000 : 1500);
  }

  /**
   * "Second wind?" The game is paused (so the eruption clock is frozen) for
   * the whole offer and the ad. Anything but an earned reward is a death.
   */
  offerRevive() {
    const c = this.campaign;
    const die = () => { if (this.campaign === c && this.state !== 'over') this.endRun('death'); };
    this.openPanel(() => this.ui.revive(this, {
      onDecline: die,
      onWatch: () => { Music.hold(true); return Ads.show().then((earned) => {
        Music.hold(false);
        if (this.campaign !== c) return;
        if (earned) this.revivePlayer(); else die();
      }); },
    }));
  }

  /**
   * Back on your feet, right here — with a real chance to get away. Hardcore
   * gets you up on a few hearts rather than a full bar.
   */
  revivePlayer() {
    const p = this.player, R = CFG.revive;
    this.campaign.revived = true;
    p.dead = false;
    p.health = this.campaign.hardcore ? Math.min(p.maxHealth, CFG.hardcore.reviveHealth) : p.maxHealth;
    p.breath = CFG.gas.breath;
    p.invuln = R.invuln;
    p.vx = 0; p.vy = 0;
    this.deathAnim = 0;

    // Lava ignores i-frames, so it has to be physically pushed back.
    if (this.volcano) this.world.lowerLava(p.y + R.lavaPush, Math.floor(p.y));

    for (const e of this.enemies) {
      const dx = e.x - p.x, dy = e.y - p.y, d = Math.hypot(dx, dy) || 1;
      if (!(e instanceof CaveBug) || d > R.clearRadius) continue;
      e.vx = (dx / d) * 10; e.vy = (dy / d) * 10 - 2;
      e.state = 'rest'; e.timer = R.stun;
    }
    for (let i = this.blocks.length - 1; i >= 0; i--) {
      const b = this.blocks[i];
      if (Math.hypot(b.x - p.x, b.y - p.y) <= R.clearRadius) this.blocks.splice(i, 1);
    }
    // A worm still going through is sent back into the rock.
    this.worms.length = 0;
    // ...and the firedamp round the miner thins out, so they can breathe.
    this.world.clearGas(p.x, p.y, R.clearRadius);

    this.closePanel();
    this.ui.syncHealth(p);
    this.ui.toast(this.campaign.hardcore ? loc('revive.doneHard', { n: p.health }) : loc('revive.done'), 1800);
    this.shake(8);
    this.fx.burst(p.x, p.y, 28, ['#ffc95e', '#fff0c0', '#7ef0d0'], { speed: 7, life: 0.9, size: 0.18, glow: true });
    Sfx.play('bank');
  }

  /* --------------------------------------------------------------- economy */

  depth() { return Math.max(0, Math.floor(this.player.y) - this.world.surface); }

  /**
   * A gem is worth the same wherever it is picked up. Depth pays by making the
   * rarer gems likelier, not by inflating the ones you already carry — so a
   * gem a bat stole near the top is worth no more for being recovered deeper.
   */
  gemValue(type) { return CFG.gems.types[type].value; }

  /** What the carried gems are worth — the only money a lantern will take. */
  purse() {
    let v = 0;
    for (const g of this.carry) v += g.value;
    return v;
  }

  /** Everything at risk right now, the Heartstone included. */
  carryValue() {
    return this.purse() + (this.player && this.player.hasHeartstone ? CFG.gems.heartstoneValue : 0);
  }

  /**
   * Pay a lantern out of the carried gems, cheapest first, so the gems a bat
   * would most like to take are the ones left in the bag. The last gem touched
   * keeps whatever change is owed, so nothing is rounded away. Every coin spent
   * here is a coin off the final score.
   */
  pay(cost) {
    if (this.purse() < cost) return false;
    this.carry.sort((a, b) => a.value - b.value);
    let owed = cost;
    while (owed > 0) {
      const g = this.carry[0];
      if (g.value <= owed) { owed -= g.value; this.carry.shift(); }
      else { g.value -= owed; owed = 0; }
    }
    this.campaign.spent += cost;
    return true;
  }

  collectGem(g) {
    g.dead = true;
    const scr = this.worldToScreen(g.x, g.y);

    if (this.tutorial) this.tutorial.notify(g.heart ? 'heart' : 'gem');
    if (g.heart) {
      this.player.hasHeartstone = true;
      this.fx.flyToHud(scr.x, scr.y, '#ff7a3c', CFG.gems.heartstoneValue);
      this.awakenVolcano();
    } else {
      // A gem a bat dropped keeps the value it was stolen at; only a gem fresh
      // out of the rock counts toward what the campaign found.
      const value = g.value !== undefined ? g.value : this.gemValue(g.type);
      this.carry.push({ type: g.type, value });
      if (!g.recovered) { this.campaign.gems++; this.campaign.found += value; }
      this.track(s => { if (g.recovered) s.recovered++; else s.gems[g.type]++; });
      Sfx.play('gem', { tier: g.type });
      if (!this.demo) this.fx.flyToHud(scr.x, scr.y, CFG.gems.types[g.type].color, value);
      this.fx.text(g.x, g.y - 0.4, '+' + fmt(value), CFG.gems.types[g.type].glow, { size: 11, life: 0.8 });
    }
    this.ui.syncWallet(this);
  }

  /** Bats take the single most valuable gem — losing junk wouldn't sting. */
  stealGem() {
    if (this.carry.length === 0) return null;
    let bi = 0;
    for (let i = 1; i < this.carry.length; i++) if (this.carry[i].value > this.carry[bi].value) bi = i;
    const gem = this.carry.splice(bi, 1)[0];
    this.ui.syncWallet(this);
    return gem;
  }

  /**
   * Every lantern is a shop, never a bank. The one at the surface camp is the
   * exit: what you carry through it is score, and the Heartstone with it opens
   * the next mine.
   */
  visitLantern(cp) {
    if (cp.home) {
      // In the practice mine the camp only ends it once the lessons are done.
      if (this.tutorial && !this.tutorial.onLastStep) { this.ui.toast(loc('tut.campEarly'), 2600); return; }
      this.reachCamp();
      return;
    }
    if (this.tutorial) this.tutorial.notify('shop');

    // Dynamite is NOT topped up here — it is stock the lantern sells. The hard
    // hat still re-forms for free; it does that on a timer out in the mine anyway.
    const rehatted = this.player.refillHat(this);
    this.ui.syncDynamite(this.player);
    this.ui.syncWallet(this);

    // A lantern out in the mine burns out as it is used: whatever you buy, you
    // buy now.
    cp.spent = true;

    // Thunks, not strings: the panel re-runs them if the language is switched
    // while it is open.
    const sub = () => {
      const bits = [loc('shop.paysFromCarry')];
      if (rehatted > 0) bits.push(loc('shop.hatRepaired'));
      return bits.join(' · ');
    };

    this.openPanel(() => this.ui.shop(this, {
      title: () => loc('shop.supplyLantern'),
      sub,
      note: () => loc('shop.singleUse'),
    }));
    if (this.player.hasHeartstone) {
      setTimeout(() => this.ui.toast(loc('toast.heartstoneAtSurface'), 2600), 400);
    }
  }

  /**
   * Walked back into the camp: the haul becomes score and this mine is over.
   * Hardcore's bonus is paid here, on what made it out, so it never makes a
   * lantern any cheaper on the way.
   */
  reachCamp() {
    const c = this.campaign;
    const p = this.player;
    const hauled = this.purse();
    const winning = p.hasHeartstone;
    const base = hauled + (winning ? CFG.gems.heartstoneValue : 0);
    const bonus = c.hardcore ? Math.round(base * CFG.hardcore.scoreBonus) : 0;
    const total = base + bonus;

    c.score += total;
    c.bonus += bonus;
    this.runStats.hauled = total;
    this.carry.length = 0;
    this.volcano = false;
    Sfx.stopRumble();

    if (total > 0) {
      Sfx.play('bank');
      this.fx.text(p.x, p.y - 0.8, loc('fx.hauled', { v: fmt(total) }), '#ffc95e', { size: 14, life: 1.5 });
      this.fx.burst(p.x, p.y, 16, ['#ffc95e', '#fff0c0'], { speed: 5, life: 0.8, size: 0.15, glow: true, grav: -2 });
    }

    if (winning && !this.tutorial) {
      p.hasHeartstone = false;
      c.hearts++;
      const secs = Math.round(this.mineTime);
      this.track(s => { s.hearts++; if (!s.fastest || secs < s.fastest) s.fastest = secs; });
      Sfx.play('win');
      this.ui.banner(loc('sum.escaped'), loc('banner.heartstonePaid', { v: fmt(CFG.gems.heartstoneValue) }));
      this.ui.syncWallet(this);
      setTimeout(() => { if (this.state === 'play') this.endRun('win'); }, 2200);
      return;
    }

    if (this.tutorial) {
      this.ui.banner(loc('tut.doneBanner'), '');
      setTimeout(() => { if (this.state === 'play') this.finishTutorial(); }, 2200);
      return;
    }
    this.ui.banner(loc('sum.complete'), loc('sum.hauledOut'));
    this.ui.syncWallet(this);
    setTimeout(() => { if (this.state === 'play') this.endRun('cashout'); }, 1400);
  }

  /** Out of the practice mine. Only the flag is saved: no score, stats or upload. */
  finishTutorial() {
    this.save.tutorial = 'done';
    this.persist();
    Sfx.stopRumble();
    this.state = 'over';
    Music.duck(false);
    Music.play('menu');
    this.input.reset();
    this.ui.syncTimer(this);
    this.ui.syncCoach(this);
    this.ui.tutorialDone();
  }

  upgradeCost(u, level) {
    return Math.round(u.base * Math.pow(u.step, level) * (level > 0 ? CFG.upgradeMarkup : 1));
  }

  /** A full reload or a full heal, priced by what it actually restores. */
  dynamiteCost(p) { return Math.max(0, p.dynMax - p.dynamite) * CFG.supplies.dynamiteCost; }
  healCost(p) { return Math.max(0, p.maxHealth - p.health) * CFG.supplies.healCost; }

  /**
   * Placeholders for an upgrade's shop description. Most upgrades hand out a
   * flat step and need none; the satchel's last level runs into the capacity
   * ceiling, so it quotes what that level actually buys rather than the step.
   */
  upgradeDescParams(u, level) {
    if (u.id === 'dynamite') {
      // A maxed row has no "next" level; quote the last one it sold instead of
      // an honest but useless "+0".
      const lv = Math.min(level, u.max - 1);
      return { n: Player.dynCapacityFor(lv + 1) - Player.dynCapacityFor(lv) };
    }
    if (u.id === 'pick') {
      // Quote the chance the next level brings (or the final one, once maxed).
      return { n: Math.round(Player.pickChanceFor(Math.min(level + 1, u.max)) * 100) };
    }
    return null;
  }

  buyUpgrade(id) {
    const u = CFG.upgrades.find(x => x.id === id);
    if (!u) return;
    const ups = this.campaign.upgrades;
    const lvl = ups[id] || 0;
    if (lvl >= u.max) return;
    const cost = this.upgradeCost(u, lvl);
    if (!this.pay(cost)) { this.ui.toast(loc('toast.notEnoughGems')); return; }

    ups[id] = lvl + 1;
    Sfx.play('buy');

    // Apply live so the purchase is felt immediately, not next run. Each stat
    // is recomputed from its level rather than nudged, so a capped level adds
    // exactly what it is worth instead of a full step.
    const p = this.player;
    if (p && !p.dead) {
      const lv = ups;
      if (id === 'health') {
        const gain = Player.maxHealthFor(lv.health) - p.maxHealth;
        p.maxHealth += gain; p.health += gain;
        this.ui.syncHealth(p);
      }
      if (id === 'speed') p.speed = Player.speedFor(lv.speed);
      if (id === 'light') p.light = Player.lightFor(lv.light);
      // A bigger satchel comes with the sticks it adds, but it is not a free
      // refill of the ones you already spent.
      if (id === 'dynamite') {
        const gain = Player.dynCapacityFor(lv.dynamite) - p.dynMax;
        p.dynMax += gain; p.dynamite += gain;
        this.ui.syncDynamite(p);
      }
      if (id === 'jump') p.jumpVel = Player.jumpVelFor(lv.jump);
      if (id === 'helmet') { p.hatMax += CFG.upgradeEffect.helmet; p.hat = p.hatMax; this.ui.syncHat(p); }
      if (id === 'blast') p.blast = Player.blastFor(lv.blast);
      if (id === 'pick') p.pickChance = Player.pickChanceFor(lv.pick);
    }
    this.ui.syncWallet(this);

    // Every panel knows how to rebuild itself, so prices and pips refresh
    // without this having to work out which shop is on screen.
    this.ui.repaint();
  }

  /**
   * Sticks are bought, never handed out, and only by the satchel-full. One
   * press for a full reload keeps the decision at the lantern a single one —
   * which matters now that a lantern in the mine is good for one visit.
   */
  buyDynamite() {
    const p = this.player;
    if (!p || p.dead) return;
    const missing = p.dynMax - p.dynamite;
    if (missing <= 0) { this.ui.toast(loc('toast.satchelFull')); return; }

    if (!this.pay(this.dynamiteCost(p))) { this.ui.toast(loc('toast.notEnoughGems')); return; }

    p.dynamite = p.dynMax;
    Sfx.play('buy');
    this.ui.syncDynamite(p);
    this.ui.syncWallet(this);
    this.ui.repaint();
  }

  /** One heal, and it is the whole bar. There is no cheap top-up any more. */
  buyHeal() {
    const p = this.player;
    if (!p || p.dead || p.health >= p.maxHealth) { this.ui.toast(loc('toast.alreadyFull')); return; }

    if (!this.pay(this.healCost(p))) { this.ui.toast(loc('toast.notEnoughGems')); return; }

    Sfx.play('buy');
    p.heal(p.maxHealth, this);
    this.ui.syncWallet(this);
    this.ui.repaint();
  }

  /* ---------------------------------------------------------------- panels */

  openPanel(builder) {
    this.state = 'paused';
    this.input.reset();
    Music.duck(true);
    builder();
  }

  closePanel() {
    if (this.state !== 'paused') return;
    this.ui.hide();
    this.input.reset();
    Music.duck(false);
    this.state = 'play';
  }

  togglePause() {
    if (this.state === 'play') this.openPanel(() => this.ui.pause(this));
    else if (this.state === 'paused') this.closePanel();
  }

  toggleAudio() {
    this.save.audio = !Sfx.enabled;
    Sfx.setEnabled(this.save.audio);
    this.persist();
    this.ui.toast(loc('toast.sound', { s: loc(this.save.audio ? 'common.on' : 'common.off') }));
  }

  toggleMusic() {
    this.save.music = !Music.enabled;
    Music.setEnabled(this.save.music);
    this.persist();
  }

  toggleShake() {
    this.save.shake = this.save.shake === false;
    if (!this.save.shake) this.shakeAmt = 0;
    this.persist();
  }

  /* -------------------------------------------------------------- spawning */

  spawnGem(x, y, type, opt) { this.gems.push(new GemPickup(x, y, type, opt)); }
  /** A gem shaken loose from a dead bat, worth exactly what it was stolen at. */
  dropStolenGem(x, y, gem) {
    this.gems.push(new GemPickup(x, y, gem.type, { speed: 3.2, value: gem.value, recovered: true }));
  }
  spawnHeartstone(x, y) { this.gems.push(new GemPickup(x, y, 0, { heart: true, speed: 1.2 })); }
  spawnFallingBlock(x, y, gas) { this.blocks.push(new FallingBlock(x, y, gas)); }

  shake(amount) {
    if (this.save.shake === false) return;
    if (this.demo) amount *= 0.35;   // behind the menu, only a tremor
    this.shakeAmt = Math.min(26, this.shakeAmt + amount);
  }

  addLight(x, y, r, life) { this.tempLights.push({ x, y, r, life, max: life }); }

  updateSpawns(dt) {
    if (this.tutorial) return;     // the practice mine's two enemies are scripted
    const depth = this.depth();
    const D = this.demo ? CFG.demo : null;   // the title demo wants a busier mine
    if (depth < (D ? D.spawnDepth : 6)) return;

    // Later mines send more of everything; the first is kept gentle.
    const threat = this.threat();
    const maxAlive = Math.max(1, Math.round(
      (CFG.spawn.maxAlive + Math.floor(depth / CFG.spawn.maxAliveDepth)) * threat)) +
      (this.volcano ? 2 : 0) + (D ? D.extraAlive : 0);
    this.spawnTimer -= dt;
    if (this.spawnTimer > 0) return;

    let interval = Math.max(CFG.spawn.intervalMin, CFG.spawn.interval - depth * CFG.spawn.intervalDepth) / threat;
    if (this.volcano) interval *= CFG.spawn.volcanoMultiplier;
    if (D) interval /= D.spawnRate;
    this.spawnTimer = interval * (0.7 + Math.random() * 0.6);
    if (this.enemies.length >= maxAlive) return;

    const spot = this.findSpawnSpot();
    if (!spot) return;

    // Bats show up when there is something worth stealing.
    const wantBat = this.carry.length > 0 && Math.random() < (D ? D.batBias : CFG.spawn.batBias);
    this.enemies.push(wantBat ? new Bat(spot.x, spot.y) : new CaveBug(spot.x, spot.y));
  }

  findSpawnSpot() {
    const w = this.world, p = this.player;
    for (let i = 0; i < 26; i++) {
      const a = Math.random() * TAU;
      const d = CFG.spawn.minDist + Math.random() * (CFG.spawn.maxDist - CFG.spawn.minDist);
      const x = Math.floor(p.x + Math.cos(a) * d);
      const y = Math.floor(p.y + Math.sin(a) * d);
      if (y <= w.surface + 1 || y >= w.h - 2) continue;
      if (w.get(x, y) !== T.EMPTY) continue;
      if (!w.isFree(x + 0.5, y + 0.5, 0.4)) continue;
      // Never pop into existence inside the player's lamp light.
      if (dist(x + 0.5, y + 0.5, p.x, p.y) < p.light + 1.5) continue;
      return { x: x + 0.5, y: y + 0.5 };
    }
    return null;
  }

  /* -------------------------------------------------------------- hazards */

  /**
   * A one-off card the first time a player meets a hazard, ever, on this
   * device. It does not pause the game, so it is kept to two short lines.
   */
  firstSight(id) {
    if (this.demo || this.save.seen[id]) return false;
    this.save.seen[id] = true;
    this.persist();
    this.ui.hint(loc('hint.' + id + '.title'), loc('hint.' + id + '.body'));
    return true;
  }

  onGasReleased(x, y, amount) {
    this.fx.drift(x, y, Math.ceil(amount * 6), ['#c8d870', '#a8c060', '#e0eaa0'],
      { life: 1.2, size: 0.18, rise: 0.8, spread: 0.8, glow: false });
    if (this.time - this._hissAt > 0.25) { this._hissAt = this.time; Sfx.play('hiss'); }
    this.firstSight('gas');
  }

  onGasIgnited(x, y) {
    this.fx.burst(x, y, 4, ['#fff3c4', '#ffb03a', '#ff6a1e'], { speed: 4, life: 0.4, size: 0.2, grav: -3, glow: true });
    if (this.time - this._whooshAt > 0.15) {
      this._whooshAt = this.time;
      Sfx.play('whoosh');
      this.shake(4);
    }
  }

  /** Fire hurts whoever stands in it and cooks off any dynamite lying in it. */
  updateFire() {
    const w = this.world;
    if (w.burning.length === 0) return;
    const p = this.player;
    if (!p.dead && w.burningAt(p.x, p.y)) p.hurt(CFG.gas.damage, this, 0, -1);
    for (const e of this.enemies) {
      if (!e.dead && w.burningAt(e.x, e.y)) e.hurt(CFG.gas.enemyDamage, this, 0, -1, 'dynamite');
    }
    for (const d of this.dynamites) {
      if (!d.dead && w.burningAt(d.x, d.y)) d.fuse = Math.min(d.fuse, 0.12);
    }
  }

  /** The worm comes round on the mine's interval, never while the volcano is awake. */
  updateWorms(dt) {
    for (let i = this.worms.length - 1; i >= 0; i--) {
      this.worms[i].update(dt, this);
      if (this.worms[i].dead) this.worms.splice(i, 1);
    }
    if (this.demo || !this.wormEvery || this.volcano || this.player.dead || this.worms.length) return;
    this.wormTimer -= dt;
    if (this.wormTimer > 0 || this.depth() < CFG.worm.minDepth) return;

    const row = this.wormRow();
    if (row === null) { this.wormTimer = 4; return; }
    // Usually from the far side, so the warning has room to be read.
    const far = this.player.x < this.world.w / 2 ? -1 : 1;
    const dir = Math.random() < 0.75 ? far : -far;
    const first = this.firstSight('worm');
    this.worms.push(new Tunneler(this.world, row, dir, first ? CFG.worm.firstWarn : CFG.worm.warn));
    const j = CFG.worm.jitter;
    this.wormTimer = Math.max(CFG.worm.minEvery, this.wormEvery * randRange([1 - j, 1 + j]));
  }

  /** A row near the player that keeps the worm clear of stations and the Heartstone chamber. */
  wormRow() {
    const W = CFG.worm, w = this.world;
    const py = Math.floor(this.player.y);
    for (let i = 0; i < 20; i++) {
      const row = py + Math.round((Math.random() * 2 - 1) * W.offset);
      if (row < w.surface + 6 || row > w.heartRow - 12) continue;
      const rel = w.stationRel(row);
      if (rel <= 4 || rel >= w.stationEvery - 2) continue;
      return row;
    }
    return null;
  }

  /* -------------------------------------------------------------- volcano */

  /** `cause` is 'heartstone' (the climax) or 'timer' (the clock ran out). */
  awakenVolcano(cause) {
    if (this.volcano) return;
    this.volcano = true;
    this.lavaSpeed = this.tutorial ? CFG.tutorial.lavaSpeed : CFG.lava.riseSpeed;
    this.world.lavaRow = Math.min(this.world.h, this.world.heartRow + CFG.lava.startOffset);
    Sfx.play('heart');
    setTimeout(() => Sfx.play('awaken'), 300);
    Sfx.startRumble();
    this.shake(26);
    this.ui.banner(loc('banner.volcano'), loc(cause === 'timer' ? 'banner.timeUp' : 'banner.climbNow'));
    this.ui.toast(loc('toast.getToSurface'), 3000);
    this.ui.syncTimer(this);
  }

  /** Seconds left on the eruption clock. Zero once the mountain is awake. */
  fuseLeft() {
    if (this.volcano) return 0;
    return Math.max(0, this.fuse - this.runTime);
  }

  /**
   * The run is on a clock whether or not the Heartstone has been found: sit in
   * the mine long enough and the mountain wakes by itself. Warnings fire on the
   * way down so the deadline is read, never sprung.
   */
  updateFuse(dt) {
    if (this.volcano || this.tutorial) return;
    this.runTime += dt;

    const warns = CFG.lava.warnAt;
    const left = this.fuseLeft();
    while (this.nextWarn < warns.length && left <= warns[this.nextWarn]) {
      const at = warns[this.nextWarn++];
      // A warning the clock skipped past (a long frame) is not worth shouting.
      if (left > at - 2) {
        Sfx.play('alert', { v: 0.8 });
        this.ui.toast(loc('toast.eruptionWarn', { t: fmtTime(left) }), 2400);
      }
    }

    if (left <= 0) this.awakenVolcano('timer');
  }

  updateLava(dt) {
    if (!this.volcano) return;
    if (!this.tutorial) this.lavaSpeed += CFG.lava.accel * dt * 60 * dt;
    // The lava floods the whole mine but stops at the surface shelf, so a
    // last-second sprint to the camp is always a legitimate win.
    const next = Math.max(this.world.surface, this.world.lavaRow - this.lavaSpeed * dt);
    this.world.riseLava(next);

    this.lavaShakeTimer -= dt;
    if (this.lavaShakeTimer <= 0) {
      this.lavaShakeTimer = CFG.lava.shakeInterval * (0.6 + Math.random() * 0.8);
      this.shake(5);
    }
    // Embers along the lava front, near the player only.
    if (Math.random() < dt * 26) {
      const x = clamp(this.player.x + (Math.random() - 0.5) * 16, 1, this.world.w - 2);
      this.fx.drift(x, this.world.lavaRow - 0.2, 1, ['#ffb03a', '#ff6a1e', '#fff0c0'],
        { life: 1.6, size: 0.16, rise: 2.6, glow: true });
    }
  }

  /* ------------------------------------------------------------ main update */

  step(dt) {
    this.time += dt;

    // Shake decays fast; the offset is re-rolled each frame for a punchy feel.
    this.shakeAmt = Math.max(0, this.shakeAmt - dt * 42);
    const s = this.shakeAmt * this.renderer.dpr * 0.5;
    this.shakeX = (Math.random() - 0.5) * s;
    this.shakeY = (Math.random() - 0.5) * s;

    this.ui.syncTimer(this);
    this.ui.syncPause(this);

    // The title runs the real mine with the demo at the controls.
    const demo = this.state === 'title' && this.demo;
    if (demo && !demo.think(dt, this)) { this.newCampaign(true); return; }

    // Paused / summary still animate the mine behind the panel.
    if (this.state !== 'play' && !demo) {
      this.fx.update(dt);
      if (this.world) { this.updateCamera(dt); this.markExplored(); this.buildLights(); }
      return;
    }

    if (!demo) { this.input.update(); this.mineTime += dt; }
    this.player.update(dt, this, demo ? demo.input : this.input);
    if (this.player.dead) this.deathAnim += dt;

    this.world.update(dt);
    this.updateFire();
    this.updateWorms(dt);
    if (!demo) this.updateFuse(dt);
    this.updateLava(dt);
    this.updateSpawns(dt);

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      // Something earlier this step (a swing, a blast, fire, the worm) may
      // already have killed it. A dead bat must not get one last steal in —
      // that gem would vanish with it.
      if (!e.dead) e.update(dt, this);
      // Cull anything that wandered far off-screen; keeps the sim cheap.
      if (e.dead || dist(e.x, e.y, this.player.x, this.player.y) > 34) {
        this.enemies[i] = this.enemies[this.enemies.length - 1];
        this.enemies.pop();
      }
    }
    for (let i = this.gems.length - 1; i >= 0; i--) {
      const g = this.gems[i];
      g.update(dt, this);
      if (g.dead) { this.gems[i] = this.gems[this.gems.length - 1]; this.gems.pop(); }
    }
    for (let i = this.dynamites.length - 1; i >= 0; i--) {
      const d = this.dynamites[i];
      d.update(dt, this);
      if (d.dead) { this.dynamites[i] = this.dynamites[this.dynamites.length - 1]; this.dynamites.pop(); }
    }
    for (let i = this.blocks.length - 1; i >= 0; i--) {
      const b = this.blocks[i];
      b.update(dt, this);
      if (b.dead) { this.blocks[i] = this.blocks[this.blocks.length - 1]; this.blocks.pop(); }
    }

    this.fx.update(dt);
    if (this.tutorial) this.tutorial.update(dt, this);
    if (!demo) {
      this.checkCheckpoint();
      const d = this.depth();
      if (d > this.runStats.depth) this.runStats.depth = d;
      this.ui.syncDepth(d, this.world, this.player);
    }

    this.updateCamera(dt);
    this.markExplored();
    this.buildLights();
  }

  /** Shut a lantern until the player has both waited and walked away. */
  lockCheckpoint(x, y) { this.checkpointLock = { x, y, t: this.time }; }

  checkCheckpoint() {
    const p = this.player;
    if (p.dead) return;

    // A lantern you just used stays shut until the cooldown has run out AND
    // you have stepped away from it. Stepping off the tile alone used to be
    // enough to re-arm it, so digging down from on top of a station reopened
    // the shop on every swing.
    const lock = this.checkpointLock;
    if (lock) {
      const dx = p.x - (lock.x + 0.5), dy = p.y - (lock.y + 0.5);
      const clear = this.time - lock.t >= CFG.checkpoint.reopenDelay &&
        Math.hypot(dx, dy) >= CFG.checkpoint.reopenDist;
      if (!clear) return;
      this.checkpointLock = null;
    }

    const tx = Math.floor(p.x), ty = Math.floor(p.y);
    if (this.world.get(tx, ty) !== T.CHECKPOINT) return;
    const cp = this.world.checkpointAt(tx, ty);
    if (!cp) return;
    this.lockCheckpoint(tx, ty);
    // A lantern down in the mine is good for exactly one visit. Locking first
    // means the "it's spent" toast fires once rather than on every step.
    if (cp.spent) { this.ui.toast(loc('toast.lanternSpent')); return; }
    this.visitLantern(cp);
  }

  updateCamera(dt) {
    const p = this.player;
    const view = CFG.render.viewTiles;
    const aspect = this.renderer.cw / this.renderer.ch;
    const halfW = (aspect >= 1 ? view * aspect : view) / 2;
    const halfH = (aspect >= 1 ? view : view / aspect) / 2;
    this.viewHalf = { w: halfW, h: halfH };

    // Lead the camera slightly toward where the player is heading. The vertical
    // lead is gentler than the horizontal one — gravity makes vy spike, and a
    // camera that snaps down on every fall is nauseating on a phone.
    const tx = p.x + clamp(p.vx * 0.16, -1.2, 1.2);
    // Behind the title the camera sits low, so the demo miner shows above the menu.
    const lift = this.state === 'title' && this.demo ? halfH * 2 * CFG.demo.camLift : 0;
    const ty = p.y + clamp(p.vy * 0.09, -1.0, 1.4) + lift;
    const k = clamp(dt * CFG.render.camLerp, 0, 1);
    this.cam.x = lerp(this.cam.x, tx, k);
    this.cam.y = lerp(this.cam.y, ty, k);

    const w = this.world;
    if (w.w > halfW * 2) this.cam.x = clamp(this.cam.x, halfW, w.w - halfW);
    else this.cam.x = w.w / 2;
    // No clamp at the bottom edge short of `floorRock`: the bedrock under the
    // floor is drawn, so the view keeps following the miner down to the end.
    this.cam.y = clamp(this.cam.y, halfH - CFG.world.surfaceRow, w.h + CFG.world.floorRock - halfH);
  }

  /** Is a point within `pad` tiles of the visible screen? */
  onScreen(x, y, pad = 0) {
    const v = this.viewHalf;
    if (!v) return true;
    return Math.abs(x - this.cam.x) <= v.w + pad && Math.abs(y - this.cam.y) <= v.h + pad;
  }

  markExplored() {
    const w = this.world, p = this.player;
    const r = Math.ceil(p.light) + 1;
    const px = Math.floor(p.x), py = Math.floor(p.y);
    const r2 = (p.light + 0.7) * (p.light + 0.7);
    for (let y = py - r; y <= py + r; y++) {
      if (y < 0 || y >= w.h) continue;
      for (let x = px - r; x <= px + r; x++) {
        if (x < 0 || x >= w.w) continue;
        if (dist2(x + 0.5, y + 0.5, p.x, p.y) > r2) continue;
        const i = y * w.w + x;
        w.explored[i] = 1;
        if (w.t[i] === T.GAS && !this.save.seen.gas) this.firstSight('gas');
      }
    }
  }

  buildLights() {
    const L = this.lights;
    L.length = 0;
    const p = this.player;
    if (!p) return;

    L.push({ x: p.x, y: p.y, r: p.light * (0.97 + p.lampFlicker * 0.06), a: 1 });
    // A tight, always-on pool so you can never be blind on your own tile.
    L.push({ x: p.x, y: p.y, r: 1.5, a: 1 });

    for (const c of this.world.checkpoints) {
      if (Math.abs(c.x - p.x) >= 26 || Math.abs(c.y - p.y) >= 20) continue;
      // A spent lantern keeps a stub of a glow — enough to recognise it as the
      // one you already used, not enough to light the room by.
      L.push({ x: c.x + 0.5, y: c.y + 0.5, r: c.spent ? 2.2 : 5.2, a: c.spent ? 0.5 : 0.9 });
    }
    for (const d of this.dynamites) L.push({ x: d.x, y: d.y, r: 2.6, a: 0.8 });
    const w = this.world;
    for (let k = 0; k < w.burning.length && k < 40; k++) {
      const i = w.burning[k];
      L.push({ x: (i % w.w) + 0.5, y: ((i / w.w) | 0) + 0.5, r: 2.2, a: 0.9 });
    }
    for (const g of this.gems) L.push({ x: g.x, y: g.y, r: g.heart ? 5 : 1.5, a: 0.75 });

    for (let i = this.tempLights.length - 1; i >= 0; i--) {
      const t = this.tempLights[i];
      t.life -= 1 / 60;
      if (t.life <= 0) { this.tempLights[i] = this.tempLights[this.tempLights.length - 1]; this.tempLights.pop(); continue; }
      L.push({ x: t.x, y: t.y, r: t.r * (t.life / t.max), a: 1 });
    }

    if (this.volcano) {
      const row = this.world.lavaRow;
      if (Math.abs(row - p.y) < 26) {
        for (let x = Math.max(1, Math.floor(p.x) - 16); x < Math.min(this.world.w - 1, Math.floor(p.x) + 16); x += 4) {
          L.push({ x: x + 0.5, y: row + 0.5, r: 7, a: 0.85 });
        }
      }
    }
  }

  worldToScreen(wx, wy) {
    const r = this.renderer;
    return {
      x: (r.ox + wx * r.ppt) / r.dpr,
      y: (r.oy + wy * r.ppt) / r.dpr,
    };
  }

  /* ------------------------------------------------------------- game loop */

  frame(nowMs) {
    const t = nowMs / 1000;
    if (this.last === undefined) this.last = t;
    // Clamp so a backgrounded tab doesn't fast-forward the whole mine.
    let dt = Math.min(0.25, t - this.last);
    this.last = t;

    this.acc += dt;
    const fixed = 1 / 60;
    let steps = 0;
    while (this.acc >= fixed && steps < 5) { this.step(fixed); this.acc -= fixed; steps++; }
    if (steps === 5) this.acc = 0;

    // Behind an open panel the mine is dimmed and blurred, and the blur is
    // re-run on every new frame — so redraw it at a quarter rate there.
    this.frameNo = (this.frameNo || 0) + 1;
    if (this.world && (!this.ui.isOpen || this.ui.showingDemo || this.frameNo % 4 === 0)) this.renderer.draw(this);
    requestAnimationFrame(this.frame.bind(this));
  }

  start() { requestAnimationFrame(this.frame.bind(this)); }
}
