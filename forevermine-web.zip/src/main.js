/* ============================================================================
 * Boot. Keep this file boring.
 * ========================================================================== */

(function () {
  function boot() {
    I18N.init();                     // before any panel or HUD label is drawn
    Native.detect();                 // before Online: the login lives in native storage
    Online.init();                   // optional; the game never waits on it
    const canvas = document.getElementById('game');
    const game = new Game(canvas);
    window.game = game;              // handy for tuning from the console
    // Refresh / Back must not eat a live run. In the app there is no page to
    // reload or history to pop — the hardware back button is Native's job.
    if (Native.app) Native.install(game);
    else ExitGuard.install(game);
    Ads.init();                      // app only: consent, then preload the revive ad
    Sfx.setEnabled(game.save.audio !== false);
    Music.setEnabled(game.save.music !== false);
    // Browsers hold all sound until the player touches something; the music
    // starts on that first touch, wherever it lands. (A touch only counts as
    // a gesture once the finger lifts, hence touchend and pointerup.) The
    // app's web view has no such rule, so there the menu music starts now.
    const unlock = () => Music.unlock();
    for (const ev of ['pointerdown', 'pointerup', 'touchend', 'keydown']) window.addEventListener(ev, unlock, true);
    if (Native.app) unlock();
    game.start();
  }

  // Kill the pinch-zoom / double-tap-zoom that would wreck a canvas game.
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault());
  document.addEventListener('touchmove', (e) => {
    if (e.touches.length > 1) e.preventDefault();
  }, { passive: false });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
